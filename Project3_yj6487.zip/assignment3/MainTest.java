package assignment3;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.Timeout;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class MainTest {
    private static Set<String> dict;
    @Rule
    public Timeout globalTimeout = Timeout.seconds(30);

    @Before // This method gets run once before each test
    public void setup() {
        Main.initialize();
        dict = Main.makeDictionary();

        // Any more initialization you want to do before each test
    }

    private static boolean differByOne(String s1, String s2) {
        if (s1.length() != s2.length()) {
            return false;
        }

        int diff = 0;
        for (int i = 0; i < s1.length(); i++) {
            if (s1.charAt(i) != s2.charAt(i) && diff++ > 1) {
                return false;
            }
        }
        return true;
    }

    private boolean verifyLadder(ArrayList<String> ladder, String start, String end) {
        String prev = null;
        if (ladder == null) {
            return true;
        }
        for (String word : ladder) {
            if (!dict.contains(word.toUpperCase()) && !dict.contains(word.toLowerCase())) {
                return false;
            }
            if (prev != null && !differByOne(prev, word)) {
                return false;
            }
            prev = word;
        }
        return ladder.size() > 0
                && ladder.get(0).toLowerCase().equals(start)
                && ladder.get(ladder.size() - 1).toLowerCase().equals(end);
    }
    // Write your JUnit tests here
    @Test
    public void testBFS1() {
        ArrayList<String> test1 = Main.getWordLadderBFS("stone", "stamp");
        if (test1 != null) {
            HashSet<String> set = new HashSet<String>(test1);
            assertEquals(set.size(), test1.size());
        }
        System.out.println("Word ladder:");
        for (String word : test1) {
            System.out.println(word);
        }

        assertNotNull(test1);
        assertNotEquals(0, test1.size());
        assertNotEquals(2, test1.size());
        assertTrue(verifyLadder(test1, "stone", "stamp"));
        assertEquals(7, test1.size());

    }

    @Test
    public void testBFS2() {
        ArrayList<String> res = Main.getWordLadderBFS("heart", "smile");
        if (res != null) {
            HashSet<String> set = new HashSet<String>(res);
            assertEquals(set.size(), res.size());
        }
        assertNotNull(res);
        assertNotEquals(0, res.size());
        assertNotEquals(2, res.size());
        assertTrue(verifyLadder(res, "heart", "smile"));

        // Output the word ladder
        System.out.println("Word ladder:");
        for (String word : res) {
            System.out.println(word);
        }
    }

    @Test
    public void testBFS3() {
        ArrayList<String> test1 = Main.getWordLadderBFS("grape", "lemon");
        if (test1 != null) {
            HashSet<String> set = new HashSet<String>(test1);
            assertEquals(set.size(), test1.size());
        }
        System.out.println("Word ladder:");
        for (String word : test1) {
            System.out.println(word);
        }
        assertNotNull(test1);
        assertNotEquals(0, test1.size());
        assertNotEquals(2, test1.size());
        assertTrue(verifyLadder(test1, "grape", "lemon"));
        assertEquals(12, test1.size());
    }

    @Test
    public void testBFS4() {
        ArrayList<String> test1 = Main.getWordLadderBFS("odium", "odour");
        if (test1 != null) {
            HashSet<String> set = new HashSet<String>(test1);
            assertEquals(set.size(), test1.size());
        }
        System.out.println("Word ladder:");
        for (String word : test1) {
            System.out.println(word);
        }
        assertNotNull(test1);
        assertNotEquals(0, test1.size());
        //assertNotEquals(2, test1.size());
        assertTrue(verifyLadder(test1, "odium", "odour"));
        assertEquals(2, test1.size());
    }
    @Test
    public void testBFS5() {
        ArrayList<String> test1 = Main.getWordLadderBFS("shirt", "flirt");
        if (test1 != null) {
            HashSet<String> set = new HashSet<String>(test1);
            assertEquals(set.size(), test1.size());
        }
        System.out.println("Word ladder:");
        for (String word : test1) {
            System.out.println(word);
        }
        assertNotNull(test1);
        assertNotEquals(0, test1.size());
        assertNotEquals(2, test1.size());
        assertTrue(verifyLadder(test1, "shirt", "flirt"));
        assertEquals(7, test1.size());
    }

    //DFS Tests

    @Test
    public void testDFS1() {
        ArrayList<String> test1 = Main.getWordLadderBFS("stone", "stamp");
        if (test1 != null) {
            HashSet<String> set = new HashSet<String>(test1);
            assertEquals(set.size(), test1.size());
        }
        System.out.println("Word ladder:");
        for (String word : test1) {
            System.out.println(word);
        }
        assertNotNull(test1);
        assertNotEquals(0, test1.size());
        assertNotEquals(2, test1.size());
        assertTrue(verifyLadder(test1, "stone", "stamp"));
        assertEquals(7, test1.size());
    }

    @Test
    public void testDFS2() {
        ArrayList<String> test1 = Main.getWordLadderBFS("paint", "sport");
        if (test1 != null) {
            HashSet<String> set = new HashSet<String>(test1);
            assertEquals(set.size(), test1.size());
        }
        System.out.println("Word ladder:");
        for (String word : test1) {
            System.out.println(word);
        }
        assertNotNull(test1);
        assertNotEquals(0, test1.size());
        assertNotEquals(2, test1.size());
        assertTrue(verifyLadder(test1, "paint", "sport"));
        assertEquals(6, test1.size());
    }

    @Test
    public void testDFS3() {
        ArrayList<String> test1 = Main.getWordLadderDFS("apply", "apple");
        if (test1 != null) {
            HashSet<String> set = new HashSet<String>(test1);
            assertEquals(set.size(), test1.size());
        }
        System.out.println("Word ladder:");
        for (String word : test1) {
            System.out.println(word);
        }
        assertNotNull(test1);
        assertNotEquals(0, test1.size());
        assertNotEquals(2, test1.size());
        assertTrue(verifyLadder(test1, "apply", "apple"));
        assertEquals(4, test1.size());

    }

    @Test
    public void testDFS4() {
        ArrayList<String> test1 = Main.getWordLadderBFS("odium", "odour");
        if (test1 != null) {
            HashSet<String> set = new HashSet<String>(test1);
            assertEquals(set.size(), test1.size());
        }
        System.out.println("Word ladder:");
        for (String word : test1) {
            System.out.println(word);
        }
        assertNotNull(test1);
        assertNotEquals(0, test1.size());
        //assertNotEquals(2, test1.size());
        assertTrue(verifyLadder(test1, "odium", "odour"));
        assertEquals(2, test1.size());
    }
    @Test
    public void testDFS5() {
        ArrayList<String> test1 = Main.getWordLadderBFS("shirt", "flirt");
        if (test1 != null) {
            HashSet<String> set = new HashSet<String>(test1);
            assertEquals(set.size(), test1.size());
        }
        System.out.println("Word ladder:");
        for (String word : test1) {
            System.out.println(word);
        }
        assertNotNull(test1);
        assertNotEquals(0, test1.size());
        assertNotEquals(2, test1.size());
        assertTrue(verifyLadder(test1, "shirt", "flirt"));
        assertEquals(7, test1.size());
    }

}