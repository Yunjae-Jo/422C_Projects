package assignment3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.*;

public class Main {
    private static Set<String> dict;

    // static variables and constants only here.

    public static void main(String[] args) throws Exception {
        Scanner kb;     // input Scanner for commands
        PrintStream ps; // output file, for student testing and grading only
        // If arguments are specified, read/write from/to files instead of Std IO.
        if (args.length != 0) {
            kb = new Scanner(new File(args[0]));
            ps = new PrintStream(new File(args[1]));
            System.setOut(ps);              // redirect output to ps
        } else {
            kb = new Scanner(System.in);    // default input from Stdin
            ps = System.out;                // default output to Stdout
        }
        initialize();
        // TODO methods to read in words, output ladder
        ArrayList<String> words = parse(kb);
        if(words.isEmpty()){
            return;
        }
        String start = words.get(0);
        String end = words.get(1);

        printLadder(getWordLadderDFS(start, end));
    }

    public static void initialize() {
        // initialize your static variables or constants here.
        // We will call this method before running our JUnit tests.  So call it
        // only once at the start of main.
        dict = makeDictionary();

    }

    /**
     * @param keyboard Scanner connected to System.in
     * @return ArrayList of Strings containing start word and end word.
     * If command is /quit, return empty ArrayList.
     */
    public static ArrayList<String> parse(Scanner keyboard) {
        // TODO
        if (!keyboard.hasNext()) {
            return new ArrayList<>();
        }
        String w1 = keyboard.next().toLowerCase();
        if (w1.equals("/quit")) {
            return new ArrayList<>();
        }
        if (!keyboard.hasNext()) {
            return new ArrayList<>();
        }
        String w2 = keyboard.next().toLowerCase();
        if (w2.equals("/quit")) {
            return new ArrayList<>();
        }
        ArrayList<String> putWord = new ArrayList<>();
        putWord.add(w1);
        putWord.add(w2);
        return putWord;
    }
    public static ArrayList<String> getWordLadderDFS(String start, String end){
        HashSet<String> visited = new HashSet<>();
        Stack<String> path = new Stack<>();
        ArrayList<String> result = new ArrayList<>();

        visited.add(start.toLowerCase());
        path.push(start.toLowerCase());
        dfs(start.toLowerCase(), end.toLowerCase(), visited, path, result);

        if(result.isEmpty()){
            result.add(start);
            result.add(end);
        }
        return new ArrayList<>(result);
    }

    private static void dfs(String start, String end, HashSet<String> visited, Stack<String> path, ArrayList<String> result){
        if(start.equals(end)){
            result.addAll(path);
            return;
        }
        int max = 100;
        if(path.size() > max){
            return;
        }

        for(String neighbor : getNeighbors(start)){
            if(!visited.contains(neighbor)){
                path.push(neighbor);
                visited.add(neighbor);
                dfs(neighbor, end, visited, path, result);
                if(!result.isEmpty()){
                    return;
                }
                path.pop();
                visited.remove(neighbor);
            }
        }
    }
    private static ArrayList<String> getNeighbors(String word){
        ArrayList<String> neighbors = new ArrayList<>();
        char[] chars = word.toCharArray();
        for(int i = 0; i < word.length(); i++){
            char oldChar = chars[i];
            for(char c = 'a'; c <= 'z'; c++){
                if (c != oldChar) {
                    chars[i] = c;
                    String newWord = new String(chars);
                    if(dict.contains(newWord.toUpperCase())){
                        neighbors.add(newWord.toLowerCase());
                    }
                }
            }
            chars[i] = oldChar;
        }
        return neighbors;
    }

    public static ArrayList<String> getWordLadderBFS(String start, String end) {
        // TODO some code
        Queue<String> queue = new ArrayDeque<>();
        HashSet<String> visited = new HashSet<>();
        HashMap<String, String> linkMap = new HashMap<>();
        queue.add(start.toLowerCase());
        visited.add(start.toLowerCase());
        while(!queue.isEmpty()){
            String currentWord = queue.remove();

            ArrayList<String> checkedWords = new ArrayList<>();
            for(int i = 0; i < currentWord.length(); i++){
                char[] cArray = currentWord.toCharArray();
                for(char c = 'a'; c <= 'z'; c++){
                    cArray[i] = c;
                    StringBuilder sb = new StringBuilder();
                    sb.append(cArray);
                    String checkExists = sb.toString();
                    if(!currentWord.equals(checkExists) && dict.contains(checkExists.toUpperCase()) && !visited.contains(checkExists)){
                        checkedWords.add(checkExists);
                    }
                }
            }

            ArrayList<String> nextWords = new ArrayList<>(checkedWords);
            for(int i = 0; i < nextWords.size(); i++){
                String neighbor = nextWords.get(i);
                if(!visited.contains(neighbor)){
                    queue.add(neighbor);
                    visited.add(neighbor);
                    linkMap.put(neighbor, currentWord);
                    if(neighbor.equals(end)){
                        ArrayList<String> ladder = new ArrayList<>();
                        String use = end;
                        while(use != null){
                            ladder.add(0, use);
                            use = linkMap.get(use);
                        }
                        return ladder;
                    }
                }
            }
        }
        ArrayList<String> ladder = new ArrayList<>();
        ladder.add(start);
        ladder.add(end);
        return ladder;
    }

    public static void printLadder(ArrayList<String> ladder) {
        int size = ladder.size()-2;
        if(size==0){
            System.out.println("no word ladder can be found between " + ladder.get(0).toLowerCase() + " and " + ladder.get(1).toLowerCase()+ ".");
        }
        else{
            System.out.println("a " + (size) + "-rung word ladder exists between " +ladder.get(0).toLowerCase()+ " and " + ladder.get(ladder.size()-1).toLowerCase()+".");
            for(int i = 0; i< ladder.size();i++) {
                System.out.println(ladder.get(i).toLowerCase());
            }
        }
    }
    // TODO
    // Other private static methods here

    /* Do not modify makeDictionary */
	public static Set<String> makeDictionary() {
        Set<String> words = new HashSet<String>();
        Scanner infile = null;
        try {
            infile = new Scanner(new File("five_letter_words.txt"));
        } catch (FileNotFoundException e) {
            System.out.println("Dictionary File not Found!");
            e.printStackTrace();
            System.exit(1);
        }
        while (infile.hasNext()) {
            words.add(infile.next().toUpperCase());
        }
        return words;
    }
}
