package assignment2;
import java.util.ArrayList;
import java.util.List;
public class PastWordBank {
    private List<String> storeGuess;
    private List<String> storeFeedback;
    public PastWordBank(){
        storeGuess = new ArrayList<>();
        storeFeedback = new ArrayList<>();
    }

    public void adding(String feedback, String guess){
        storeGuess.add(guess);
        storeFeedback.add(feedback);
    }

    public void printing(){
        for(int i = 0; i < storeGuess.size(); i++){
            System.out.println(storeGuess.get(i) + "->" + storeFeedback.get(i));
        }
        System.out.println("--------");
    }

}
