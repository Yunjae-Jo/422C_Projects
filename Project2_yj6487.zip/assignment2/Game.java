package assignment2;
import java.util.Scanner;

public class Game {
//TODO: Design a Game.java class to handle top-level gameplay
//You may add whatever constructor or methods you like
    private GameConfiguration config;
    private Scanner scanner;
    private String secretWord;
    private int guessesLeft;
    private int wordLength;
    private String guess;
    Dictionary name;
    PastWordBank wordBank = new PastWordBank();
    public Game(GameConfiguration config, Scanner scanner) {
        this.config = config;
        this.scanner = scanner;
        this.guessesLeft = config.numGuesses;
        this.wordLength = config.wordLength;
        if(config.wordLength == 4){
            this.name = new Dictionary("4_letter_words.txt");
        }
        if(config.wordLength == 5){
            this.name = new Dictionary("5_letter_words.txt");
        }
        if(config.wordLength == 6){
            this.name = new Dictionary("6_letter_words.txt");
        }
    }
    public void runGame(){
        System.out.println("Hello! Welcome to Wordle.");
        while(true) {
            System.out.println("Do you want to play a new game? (y/n)");
            String playYesOrNo = scanner.nextLine();
            if(playYesOrNo.equals("y")){
                secretWord = name.getRandomWord();
                playGame();
            }
            else if(playYesOrNo.equals("n")){
                break;
            }
        }
    }
    public void playGame(){
        if(config.testMode) {
            System.out.println(secretWord);
        }
        int guessRemain = guessesLeft;
        while(guessesLeft > 0){
            System.out.println("Enter your guess:");
            guess = scanner.nextLine();
            if(guess.equals("[history]")){
                wordBank.printing();
            }
            if(guess.length() == config.wordLength){
                if(name.containsWord(guess)){
                    guessRemain--;
                    Feedback feedback = new Feedback(guess, secretWord, guess.length());
                    feedback.checkForFeedback();
                    wordBank.adding(feedback.getFeedback(), guess);
                    if(guess.equals(secretWord)){
                        System.out.println("Congratulations! You have guessed the word correctly.");
                        break;
                    }
                    System.out.println("You have " + guessRemain + " guess(es) remaining.");
                    if(guessRemain == 0){
                        System.out.println("You have run out of guesses.");
                        System.out.println("The correct word was \"" + secretWord + "\"");
                        break;
                    }
                }
                else{
                    System.out.println("This word is not in the dictionary. Please try again.");
                }
            }
            else{
                if(!guess.equals("[history]")){
                    System.out.println("This word has an incorrect length. Please try again.");
                }
            }
        }

    }
}