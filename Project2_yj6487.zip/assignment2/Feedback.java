package assignment2;

public class Feedback {
    private String check;
    private String answerWord;
    private String feedback;
    private int wordLength;
    private int[] letterRepeat;
    private int repeat;
    public Feedback(String check, String answerWord, int wordLength){
        this.check = check;
        this.answerWord = answerWord;
        this.wordLength = wordLength;
        this.letterRepeat = new int[26];
        countLetterOccurrences();
    }
    public void countLetterOccurrences() {
        for (char letter : answerWord.toCharArray()) {
            letterRepeat[letter - 'a'] = letterRepeat[letter - 'a'] + 1;
        }
    }
    public void checkForFeedback(){
        StringBuilder sb = new StringBuilder();
        int[] remaining = letterRepeat.clone();
        for(int i  = 0; i < wordLength; i++){
            char firstCheck = check.charAt(i);
            boolean found = false;
            if(firstCheck == answerWord.charAt(i)){
                sb.append('G');
                found = true;
                remaining[firstCheck - 'a']--;
                if(remaining[firstCheck - 'a'] < 0){
                    sb.deleteCharAt(repeat);
                    sb.insert(repeat, '_');
                }
            }
            else {
                if (remaining[firstCheck - 'a'] > 0) {
                    sb.append('Y');
                    found = true;
                    remaining[firstCheck - 'a']--;
                    repeat = i;
                }
            }
            if(!found){
                sb.append('_');
            }
        }
        feedback = sb.toString();
        System.out.println(feedback);
    }
    public String getFeedback(){
        return feedback;
    }
}
