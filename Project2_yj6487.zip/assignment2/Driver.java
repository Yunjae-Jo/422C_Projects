package assignment2;

import java.util.Scanner;

public class Driver {

    public void start(GameConfiguration config) {
        // TODO: complete this method
        // We will call this method from our JUnit test cases.
        Game newgame = new Game(config, new Scanner(System.in));
        newgame.runGame();
    }

    public void start_hardmode(GameConfiguration config) {
        // TODO: complete this method for extra credit
        // We will call this method from our JUnit test cases.
    }
    public static void main(String[] args) {
        // Use this for your testing.  We will not be calling this method.
        Driver driver = new Driver();
        GameConfiguration config = new GameConfiguration(5,6,false);
        driver.start(config);
    }
}
