import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;
public class client extends Application {
    private Socket socket;
    private ObjectOutputStream toServer;
    private ObjectInputStream fromServer;
    public static void main(String[] args) {
        launch(args);
    }
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Online Library System");
        connectToServer();
        showLogin(primaryStage);
    }
    private void connectToServer() {
        try {
            if (socket != null && !socket.isClosed()) {
                return;
            }
            socket = new Socket("localhost", 8000);
            toServer = new ObjectOutputStream(socket.getOutputStream());
            fromServer = new ObjectInputStream(socket.getInputStream());
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Unable to connect to server: " + ex.getMessage());
        }
    }
    private void showLogin(Stage stage) {
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setHgap(10);
        pane.setVgap(10);
        TextField txtUsername = new TextField();
        txtUsername.setPromptText("Username");
        PasswordField txtPassword = new PasswordField();
        txtPassword.setPromptText("Password");
        txtPassword.setPrefWidth(150);
        txtPassword.setPrefHeight(40);
        Button btnLogin = new Button("Login");
        pane.add(new Label("Username:"), 0, 0);
        pane.add(txtUsername, 1, 0);
        pane.add(new Label("Password:"), 0, 1);
        pane.add(txtPassword, 1, 1);
        pane.add(btnLogin, 1, 2);
        btnLogin.setOnAction(e -> {
            try {
                toServer.writeObject("login " + txtUsername.getText() + " " + txtPassword.getText());
                toServer.flush();
                String response = (String) fromServer.readObject();
                if (response.startsWith("Login successful")) {
                    showMainInterface(stage, response.split(" ")[3]);
                } else {
                    showErrorMessage(stage, response, true);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                showErrorMessage(stage, "Connection to server failed.", true);
            }
        });
        Scene scene = new Scene(pane, 300, 200);
        stage.setScene(scene);
        stage.show();
    }
    private void showPasswordReset(Stage stage, String username) {
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setHgap(10);
        pane.setVgap(10);
        TextField txtOldPassword = new TextField();
        txtOldPassword.setPromptText("Current Password");
        TextField txtNewPassword = new TextField();
        txtNewPassword.setPromptText("New Password");
        Button btnSubmit = new Button("Submit");
        pane.add(new Label("Current Password:"), 0, 0);
        pane.add(txtOldPassword, 1, 0);
        pane.add(new Label("New Password:"), 0, 1);
        pane.add(txtNewPassword, 1, 1);
        pane.add(btnSubmit, 1, 2);
        btnSubmit.setOnAction(e -> {
            performPasswordReset(username, txtOldPassword.getText(), txtNewPassword.getText(), stage);
        });
        Scene scene = new Scene(pane, 300, 200);
        stage.setScene(scene);
    }
    private void performPasswordReset(String username, String oldPassword, String newPassword, Stage stage) {
        try {
            toServer.writeObject("reset_password " + username + " " + oldPassword + " " + newPassword);
            toServer.flush();
            String response = (String) fromServer.readObject();
            if (response.equals("Password successfully updated.")) {
                showMainInterface(stage, username);
            } else {
                showErrorMessage(stage, response, true);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            showErrorMessage(stage, "Failed to reset password.", true);
        }
    }
    private void showMainInterface(Stage stage, String username) {
        VBox vbox = new VBox(10);
        vbox.setAlignment(Pos.CENTER);
        Label userLabel = new Label("Logged in as: " + username);
        TextField txtSearchQuery = new TextField();
        txtSearchQuery.setPromptText("Enter search query");
        Button btnSearch = new Button("Search");
        Button btnListAll = new Button("List All Books");
        ListView<String> bookList = new ListView<>();
        bookList.setPrefHeight(200);
        TextField txtItemId = new TextField();
        txtItemId.setPromptText("Enter item ID");
        Button btnCheckout = new Button("Checkout");
        Button btnViewHistory = new Button("View My History");
        Button btnReserve = new Button("Reserve");
        Button btnReturn = new Button("Return");
        Button btnPasswordReset = new Button("Reset Password");
        Button btnLogout = new Button("Logout");
        Label lblResponse = new Label();
        btnListAll.setOnAction(e -> {
            listAllBooks(bookList);
        });
        btnSearch.setOnAction(e -> {
            String searchQuery = txtSearchQuery.getText().trim();
            if (!searchQuery.isEmpty()) {
                performSearch("search " + searchQuery, bookList);
            } else {
                bookList.getItems().clear();
                bookList.getItems().add("Please enter a search query.");
            }
        });
        btnCheckout.setOnAction(e -> {
            if (!txtItemId.getText().trim().isEmpty()) {
                performAction("checkout " + txtItemId.getText().trim(), lblResponse);
            } else {
                lblResponse.setText("Please enter a valid item ID.");
            }
        });
        btnReserve.setOnAction(e -> {
            if (!txtItemId.getText().trim().isEmpty()) {
                performAction("reserve " + txtItemId.getText().trim(), lblResponse);
            } else {
                lblResponse.setText("Please enter a valid item ID to reserve.");
            }
        });
        btnReturn.setOnAction(e -> {
            String itemId = txtItemId.getText().trim();
            if (!itemId.isEmpty()) {
                performAction("return " + itemId, lblResponse);
            } else {
                lblResponse.setText("Please enter a valid item ID to return.");
            }
        });
        btnLogout.setOnAction(e -> {
            logout(stage);
        });
        btnViewHistory.setOnAction(e -> {
            performViewHistory(username, stage);
        });
        btnPasswordReset.setOnAction(e -> showPasswordReset(stage, username));
        vbox.getChildren().addAll(
                userLabel,
                txtSearchQuery, btnSearch,
                btnListAll, bookList,
                txtItemId,
                btnCheckout, btnReturn,
                btnReserve,
                btnViewHistory,
                btnPasswordReset,
                lblResponse,
                btnLogout
        );

        Scene scene = new Scene(vbox, 400, 600);
        stage.setScene(scene);
    }
    private void showHistoryScreen(Stage stage, String username, List<String> history) {
        VBox vbox = new VBox(10);
        vbox.setAlignment(Pos.CENTER);

        ListView<String> historyList = new ListView<>();
        historyList.getItems().addAll(history);

        Button backButton = new Button("Back to Main Interface");
        backButton.setOnAction(e -> showMainInterface(stage, username));

        vbox.getChildren().addAll(historyList, backButton);

        Scene historyScene = new Scene(vbox, 400, 400);
        stage.setScene(historyScene);
    }
    private void logout(Stage stage) {
        try {
            if (toServer != null) {
                toServer.writeObject("logout");
                toServer.flush();
            }
            if (fromServer != null) {
                fromServer.close();
            }
            if (toServer != null) {
                toServer.close();
            }
            if (socket != null) {
                socket.close();
            }
            connectToServer();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        showLogin(stage);
    }
    private void listAllBooks(ListView<String> bookList) {
        try {
            toServer.writeObject("list_all");
            toServer.flush();
            List<String> books = (List<String>) fromServer.readObject();
            bookList.getItems().clear();
            bookList.getItems().addAll(books);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    private void performSearch(String command, ListView<String> bookList) {
        try {
            toServer.writeObject(command);
            toServer.flush();

            Object response = fromServer.readObject();
            if (response instanceof List) {
                List<String> results = (List<String>) response;
                bookList.getItems().clear();
                if (!results.isEmpty()) {
                    bookList.getItems().addAll(results);
                } else {
                    bookList.getItems().add("No results found.");
                }
            } else {
                System.out.println("Unexpected response type from server.");

            }
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error during search operation: " + ex.getMessage());
        }
    }
    private void performAction(String command, Label responseLabel) {
        try {
            toServer.writeObject(command);
            toServer.flush();
            String response = (String) fromServer.readObject();
            responseLabel.setText(response);
        } catch (Exception ex) {
            responseLabel.setText("Failed to perform operation: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
    private void performViewHistory(String username, Stage stage) {
        try {
            toServer.writeObject("history " + username);
            toServer.flush();
            List<String> history = (List<String>) fromServer.readObject();
            showHistoryScreen(stage, username, history);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    private void showErrorMessage(Stage stage, String message, boolean showBackButton) {
        VBox layout = new VBox(10);
        layout.setAlignment(Pos.CENTER);

        Label errorLabel = new Label(message);
        layout.getChildren().add(errorLabel);

        if (showBackButton) {
            Button backButton = new Button("Back");
            backButton.setOnAction(e -> showLogin(stage));
            layout.getChildren().add(backButton);
        }

        Scene scene = new Scene(layout, 300, 150);
        stage.setScene(scene);
    }
}