import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
public class userManager {
    private ConcurrentHashMap<String, userUpdate> activeSessions;
    private ConcurrentHashMap<String, String> userCredentials;
    public userManager() {
        this.userCredentials = new ConcurrentHashMap<>();
        this.activeSessions = new ConcurrentHashMap<>();
        loadUserCredentials();
    }
    private void loadUserCredentials() {
        Gson gson = new Gson();
        try (FileReader reader = new FileReader("C:\\Users\\yunja\\Desktop\\finalProject6422c\\serverSide\\src\\users.txt")) {
            List<User> users = gson.fromJson(reader, new TypeToken<List<User>>() {}.getType());
            users.forEach(user -> userCredentials.put(user.getUsername(), user.getPassword()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public synchronized String resetPassword(String username, String oldPassword, String newPassword) {
        if (!userCredentials.get(username).equals(oldPassword)) {
            return "Incorrect current password.";
        }
        if (oldPassword.equals(newPassword)) {
            return "New password cannot be the same as the old password.";
        }
        userCredentials.put(username, newPassword);
        saveUserCredentials();
        return "Password successfully updated.";
    }
    private void saveUserCredentials() {
        Gson gson = new Gson();
        List<User> users = new ArrayList<>();
        userCredentials.forEach((username, password) -> users.add(new User(username, password)));
        try (FileWriter writer = new FileWriter("C:\\Users\\yunja\\Desktop\\finalProject6422c\\serverSide\\src\\users.txt")) {
            gson.toJson(users, writer);
        } catch (IOException e) {
            System.out.println("Failed to save user credentials: " + e.getMessage());
            e.printStackTrace();
        }
    }
    public String loginUser(String username, String password) {
        if (!userCredentials.containsKey(username) || !userCredentials.get(username).equals(password)) {
            return "Invalid username or password.";
        }
        if (activeSessions.containsKey(username)) {
            return "User already logged in.";
        }
        activeSessions.put(username, new userUpdate(username));
        return "Login successful for " + username;
    }
    public String logoutUser(String username) {
        if (activeSessions.containsKey(username)) {
            activeSessions.remove(username);
            return "Logout successful.";
        }
        return "User not found or already logged out.";
    }
    public void logUserEvent(String username, String event) {
        userUpdate session = activeSessions.get(username);
        if (session != null) {
            session.logEvent(event);
        } else {
            System.out.println("No active session for user: " + username);
        }
    }
    public synchronized List<String> getUserHistory(String username) {
        userUpdate session = activeSessions.get(username);
        if (session != null) {
            return session.getHistoryLog();
        }
        return new ArrayList<>();
    }
    private class User {
        private String username;
        private String password;
        public User(String username, String password) {
            this.username = username;
            this.password = password;
        }
        public String getUsername() {
            return username;
        }
        public String getPassword() {
            return password;
        }
    }
}
class userUpdate {
    private String username;
    private List<String> historyLog;
    private static final String HISTORY_FILE_PATH = "history.txt";
    public userUpdate(String username) {
        this.username = username;
        this.historyLog = loadHistory();
    }
    private List<String> loadHistory() {
        Gson gson = new Gson();
        File historyFile = new File(HISTORY_FILE_PATH + username + "_history.json");
        if (!historyFile.exists()) {
            return new ArrayList<>();
        }
        try (FileReader reader = new FileReader(historyFile)) {
            return gson.fromJson(reader, new TypeToken<List<String>>(){}.getType());
        } catch (IOException e) {
            System.out.println("Failed to load history for user: " + username);
            return new ArrayList<>();
        }
    }
    public void saveHistory() {
        Gson gson = new Gson();
        try (FileWriter writer = new FileWriter(HISTORY_FILE_PATH + username + "_history.json")) {
            gson.toJson(historyLog, writer);
        } catch (IOException e) {
            System.out.println("Failed to save history for user: " + username);
            e.printStackTrace();
        }
    }
    public void logEvent(String event) {
        historyLog.add(event);
        saveHistory();
    }
    public List<String> getHistoryLog() {
        return new ArrayList<>(historyLog);
    }
}