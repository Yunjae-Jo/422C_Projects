package unittest.listeners;

import javafx.application.Platform;
import javafx.scene.control.ListView;
import unittest.results.TestMethodResult;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class GUITestListener implements TestListener {
    private ListView<String> listResult;
    private Map<String, Integer> testMethodIndices;
    private List<String> failureMessages;

    public GUITestListener(ListView<String> listResult) {
        this.listResult = listResult;
        this.testMethodIndices = new HashMap<>();
        this.failureMessages = new ArrayList<>();
    }

    @Override
    public void testStarted(String testMethod) {
        Platform.runLater(() -> {
                listResult.getItems().add(testMethod + " - Running...");
                testMethodIndices.put(testMethod, listResult.getItems().size() - 1);
        });
    }
    @Override
    public void testSucceeded(TestMethodResult testMethodResult) {
        updateTestStatus(testMethodResult.getName(), "PASS");
    }

    @Override
    public void testFailed(TestMethodResult testMethodResult) {
        String methodName = testMethodResult.getName();
        updateTestStatus(testMethodResult.getName(), "FAIL");
        if (testMethodResult.getException() != null) {
            displayExceptionStackTrace(methodName, testMethodResult.getException());
        }

    }
    private void updateTestStatus(String testMethod, String status) {
        Platform.runLater(() -> {
            int index = testMethodIndices.get(testMethod);
            listResult.getItems().set(index,testMethod + " : " + status);
        });
    }
    private void displayExceptionStackTrace(String testMethod, Throwable exception) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        exception.printStackTrace(pw);
        String stackTrace = sw.toString();
        failureMessages.add(testMethod + ":\n" + stackTrace);

    }
    public void displayFailures() {
        Platform.runLater(() -> {
            listResult.getItems().add("==========");
            listResult.getItems().add("FAILURES:");
            failureMessages.forEach(failure -> listResult.getItems().add(failure));
        });
    }

}
