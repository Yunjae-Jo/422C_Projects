package unittest.driver;

import unittest.annotations.Ordered;
import unittest.results.TestClassResult;
import unittest.runners.FilteredTestRunner;
import unittest.runners.OrderedTestRunner;
import unittest.runners.TestRunner;
import unittest.results.TestMethodResult;
import java.util.ArrayList;
import java.util.List;

public class TestDriver {

    public static List<TestClassResult> runTests(String[] testclasses) {
        int numFailure = 0;
        int totalTestsRun = 0;
        List<String> check = new ArrayList<>();
        List<TestClassResult> finalResults = new ArrayList<>();

        for (String name : testclasses) {
            try {
                Class<?> classBeingTested;
                boolean methodExists = false;
                List<String> methodsList = new ArrayList<>();
                if (name.contains("#")) {
                    methodExists = true;
                    int checkHash = name.indexOf('#');
                    String className = name.substring(0, checkHash);
                    classBeingTested = Class.forName(className);
                    String TotalMethod = name.substring(checkHash + 1);

                    int startingIndex = 0;
                    for (int i = 0; i < TotalMethod.length(); i++) {
                        if (TotalMethod.charAt(i) == ',' || i == TotalMethod.length() - 1) {
                            int endForOne;
                            if (i == TotalMethod.length() - 1) {
                                endForOne = i + 1;
                            }
                            else {
                                endForOne = i;
                            }
                            String methodName = TotalMethod.substring(startingIndex, endForOne);
                            methodsList.add(methodName);
                            startingIndex = i + 1;
                        }
                    }
                }
                else {
                    classBeingTested = Class.forName(name);
                }


                TestRunner runner;

                if (classBeingTested.isAnnotationPresent(Ordered.class)) {
                    runner = new OrderedTestRunner(classBeingTested);
                }
                else {
                    if(methodExists){
                        runner = new FilteredTestRunner(classBeingTested, methodsList);
                    }
                    else{
                        runner = new TestRunner(classBeingTested);
                    }
                }

                TestClassResult result = runner.run();
                finalResults.add(result);

                for (TestMethodResult outResult : result.getTestMethodResults()) {
                    if(outResult.isPass()){
                        System.out.println(result.getTestClassName() + "." + outResult.getName() + " : " + "PASS");
                    }
                    else{
                        System.out.println(result.getTestClassName() + "." + outResult.getName() + " : " + "FAIL");
                    }
                    totalTestsRun++;
                }
            }
            catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        numFailure = printFailures(finalResults,check,numFailure);

        System.out.println("==========");
        System.out.println("Tests run: " + totalTestsRun + ", Failures: " + numFailure);
        numFailure = 0;
        return finalResults;

    }
    private static int printFailures(List<TestClassResult> finalResults,List<String> check,int numFailure) {
        boolean hasFailures = false;
        for (TestClassResult result : finalResults) {
            List<TestMethodResult> methodResults = result.getTestMethodResults();
            for (TestMethodResult tmResult : methodResults) {
                if (!tmResult.isPass()) {
                    hasFailures = true;
                    break;
                }
            }
            if (hasFailures) {
                break;
            }
        }
        if (hasFailures) {
            System.out.println("==========");
            System.out.println("FAILURES:");
            for (TestClassResult tResult : finalResults) {
                for (TestMethodResult tmResult : tResult.getTestMethodResults()) {
                    if (!tmResult.isPass()) {
                        if(!check.contains(tResult.getTestClassName()) || !check.contains(tmResult.getName())) {
                            check.add(tResult.getTestClassName());
                            check.add(tmResult.getName());
                            numFailure++;
                            System.out.println(tResult.getTestClassName() + "." + tmResult.getName() + ":");
                            if (tmResult.getException() != null) {
                                tmResult.getException().printStackTrace();
                            }
                        }
                    }
                }
            }
        }
        else {
            System.out.println("==========");
            System.out.println("FAILURES:");
        }
        return numFailure;
    }
    public static void main(String[] args) {
        runTests(args);
    }
}