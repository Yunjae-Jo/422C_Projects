package unittest.runners;

import unittest.annotations.Order;
import unittest.annotations.Test;
import unittest.assertions.ComparisonException;
import unittest.listeners.TestListener;
import unittest.results.TestClassResult;
import unittest.results.TestMethodResult;
import unittest.assertions.AssertionException;
import java.lang.reflect.Method;
import java.util.*;


public class OrderedTestRunner extends TestRunner {

    public OrderedTestRunner(Class<?> testClass) {
        super(testClass);
    }
    private TestListener listener;

    @Override
    public TestClassResult run() {
        TestClassResult finalResults = new TestClassResult(testClass.getName());
        Method[] testMethods = getOrderedTestMethods();
        for (Method method : testMethods) {
            TestMethodResult finalResult = runTestMethod(method);
            finalResults.addTestMethodResult(finalResult);
        }
        return finalResults;
    }

    private Method[] getOrderedTestMethods() {
        Set<String> methodNames = new HashSet<>();
        List<Method> testMethods = new ArrayList<>();
        Class<?> currentClass = testClass;
        while (currentClass != null) {
            for (Method method : currentClass.getDeclaredMethods()) {
                if (method.isAnnotationPresent(Test.class) && methodNames.add(method.getName())) {
                    testMethods.add(method);
                }
            }
            currentClass = currentClass.getSuperclass();
        }
        testMethods.sort((i, j) -> {
            Order a = i.getAnnotation(Order.class);
            Order b = j.getAnnotation(Order.class);
            int c = a != null ? a.value() : Integer.MAX_VALUE;
            int d = b != null ? b.value() : Integer.MAX_VALUE;
            if (c != d) {
                return Integer.compare(c, d);
            } else {
                return i.getName().compareTo(j.getName());
            }
        });

        return testMethods.toArray(new Method[0]);
    }


    private TestMethodResult runTestMethod(Method method) {
        try {
            if (listener != null) {
                listener.testStarted(method.getName());
            }
            Object run = testClass.getDeclaredConstructor().newInstance();
            method.invoke(run);
            TestMethodResult result = new TestMethodResult(method.getName(), true, null);
            if (listener != null) {
                listener.testSucceeded(result);
            }
            return result;
        }
        catch (Exception e) {
            TestMethodResult result;
            if (e.getCause() instanceof AssertionException) {
                result = new TestMethodResult(method.getName(), false, (AssertionException) e.getCause());
            }
            else if (e.getCause() instanceof ComparisonException) {
                result = new TestMethodResult(method.getName(), false, (ComparisonException) e.getCause());
            }
            else {
                return null;
            }
            if (listener != null) {
                listener.testFailed(result);
            }
            return result;
        }
    }
    public void addListener(TestListener listener) {
        this.listener = listener;
    }
}
