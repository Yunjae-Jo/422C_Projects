package unittest.gui;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import unittest.annotations.Ordered;
import unittest.listeners.GUITestListener;
import unittest.listeners.TestListener;
import unittest.runners.FilteredTestRunner;
import unittest.runners.OrderedTestRunner;
import unittest.runners.TestRunner;
import unittest.results.TestClassResult;
import unittest.results.TestMethodResult;
import java.util.ArrayList;
import java.util.List;


public class TestGUIController {
    @FXML
    private ListView<String> listResult;
    @FXML
    private Button startTestsButton;
    @FXML
    private TextField inputTest;
    @FXML
    private ListView<String> availableTests;
    private TestListener listener;
    private GUITestListener listener2;

    public void initialize() {
        availableTests.getItems().addAll("sampletest.TestA\nsampletest.TestB\nsampletest.TestC\nsampletest.TestD\nsampletest.TestE\nsampletest.TestF\n");
    }
    @FXML
    private void handleStartTestsAction() {
        Platform.runLater(() -> listResult.getItems().clear());
        listener = new GUITestListener(listResult);
        listener2 = new GUITestListener(listResult);
        new Thread(() -> {
            int totalTestsRun = 0;
            int numFailures = 0;
            List<TestClassResult> finalResults = new ArrayList<>();
            String[] testClassName;
            String input = inputTest.getText();
            testClassName = input.split(" ");

            for (String name : testClassName) {
                try {
                    Class<?> classBeingTested;
                    boolean methodExists = false;
                    List<String> methodsList = new ArrayList<>();

                    if (name.contains("#")) {
                        methodExists = true;
                        int checkHash = name.indexOf('#');
                        String className = name.substring(0, checkHash);
                        classBeingTested = Class.forName(className);
                        String totalMethod = name.substring(checkHash + 1);

                        int startingIndex = 0;
                        for (int i = 0; i < totalMethod.length(); i++) {
                            if (totalMethod.charAt(i) == ',' || i == totalMethod.length() - 1) {
                                int endForOne = (i == totalMethod.length() - 1) ? i + 1 : i;
                                String methodName = totalMethod.substring(startingIndex, endForOne);
                                methodsList.add(methodName);
                                startingIndex = i + 1;
                            }
                        }
                    }
                    else {
                        classBeingTested = Class.forName(name);
                    }

                    TestRunner runner;
                    if (classBeingTested.isAnnotationPresent(Ordered.class)) {
                        runner = new OrderedTestRunner(classBeingTested);
                    }
                    else {
                        runner = methodExists ? new FilteredTestRunner(classBeingTested, methodsList) : new TestRunner(classBeingTested);
                    }

                    runner.addListener(listener);
                    runner.addListener(listener2);
                    TestClassResult result = runner.run();
                    finalResults.add(result);

                    for (TestMethodResult outResult : result.getTestMethodResults()) {
                        totalTestsRun++;
                            if (!outResult.isPass()) {
                                numFailures++;
                            }
                    }
                }
                catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
                listener2.displayFailures();
            String finalStatus = "==========\nTests run: " + totalTestsRun + ", Failures: " + numFailures;
            Platform.runLater(() -> {
                listResult.getItems().add(finalStatus);
            });
        }).start();
    }
}
