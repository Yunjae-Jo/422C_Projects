package assignment6;


import assignment6.Seat.SeatType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class MovieTheater {
    private SalesLogs log;
    private Map<SeatType, ArrayList<Seat>> availableSeats;
    /**
     * Constructs a MovieTheater, where there are a set number of rows per seat type.
     *
     * @param rumbleNum the number of rows with rumble seats.
     * @param comfortNum the number of rows with comfort seats.
     * @param standardNum the number of rows with standard seats.
     */
    public MovieTheater(int rumbleNum, int comfortNum, int standardNum){
        this.log = new SalesLogs();
        this.availableSeats = new HashMap<>();
        setSeats(SeatType.RUMBLE, rumbleNum, 1);
        setSeats(SeatType.COMFORT, comfortNum, rumbleNum + 1);
        setSeats(SeatType.STANDARD, standardNum, rumbleNum + comfortNum + 1);
    }
    private void setSeats(SeatType seatType, int numRows, int startingRow) {
        ArrayList<Seat> seats = new ArrayList<>();
        for (int row = startingRow; row < startingRow + numRows; row++) {
            for (int i = 0; i < Seat.SeatLetter.values().length; i++) {
                Seat.SeatLetter letter = Seat.SeatLetter.values()[i];
                seats.add(new Seat(seatType, row, letter));
            }
        }
        availableSeats.put(seatType, seats);
    }


    /**
     * Returns the next available seat not yet reserved for a given seat type.
     *
     * @param seatType the type of seat (RUMBLE, COMFORT, STANDARD).
     * @return the next available seat or null if the theater is full.
     */


    public Seat getNextAvailableSeat(SeatType seatType) {
        Seat seat = findSeat(seatType);
        if (seat != null) {
            return seat;
        }
        if (seatType == Seat.SeatType.RUMBLE) {
            seat = findSeat(Seat.SeatType.COMFORT);
            if (seat != null) {
                return seat;
            }
            seat = findSeat(Seat.SeatType.STANDARD);
            if (seat != null) {
                return seat;
            }
        } else if (seatType == Seat.SeatType.COMFORT) {
            seat = findSeat(Seat.SeatType.STANDARD);
            if (seat != null) {
                return seat;
            }
        }


        return null;
    }
    private Seat findSeat(SeatType seatType) {
        List<Seat> seats = availableSeats.get(seatType);
        if (!seats.isEmpty()) {
            return seats.remove(0);
        }
        return null;
    }


    /**
     * Prints a ticket to the console for the customer after they reserve a seat.
     *
     * @param boothId id of the ticket booth.
     * @param seat a particular seat in the theater.
     * @return a movie ticket or null if a ticket booth failed to reserve the seat.
     */
    public Ticket printTicket(String boothId, Seat seat, int customer) {
        // TODO: Implement this method.
        Ticket ticket = new Ticket(boothId, seat, customer);
        log.addTicket(ticket);
        log.addSeat(seat);
        System.out.println(ticket);
        return ticket;
    }


    /**
     * Lists all seats sold for the movie in the order of reservation.
     *
     * @return list of seats sold.
     */
    public List<Seat> getSeatLog() {
        // TODO: Implement this method.
        return log.getSeatLog();
    }


    /**
     * Lists all tickets sold for the movie in order of printing.
     *
     * @return list of tickets sold.
     */


    public List<Ticket> getTransactionLog() {
        // TODO: Implement this method.
        return log.getTicketLog();
    }


    static class SalesLogs {


        private ArrayList<Seat> seatLog;
        private ArrayList<Ticket> ticketLog;


        private SalesLogs() {
            seatLog = new ArrayList<Seat>();
            ticketLog = new ArrayList<Ticket>();
        }


        public List<Seat> getSeatLog() {
            return (List<Seat>)(seatLog.clone());
        }


        public List<Ticket> getTicketLog() {
            return (List<Ticket>)(ticketLog.clone());
        }


        public void addSeat(Seat s) {
            seatLog.add(s);
        }


        public void addTicket(Ticket t) {
            ticketLog.add(t);
        }
    }
}
