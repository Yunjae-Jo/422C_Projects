package assignment6;


import assignment6.Seat.SeatType;


import java.util.List;
import java.util.ArrayList;
import java.util.Map;
public class Cinema {
    /**
     * Constructor to initilize the simulation based on starter parameters.
     *
     * @param booths maps ticket booth id to seat type preferences of customers in line.
     * @param movieTheater the theater for which tickets are sold.
     */
    private Map<String, SeatType[]> booths;
    private MovieTheater movieTheater;
    protected int customerIdCounter = 0;
    private final Object counterLock = new Object();
    public Cinema(Map<String, SeatType[]> booths, MovieTheater movieTheater) {
        // TODO: Implement this constructor
        this.booths = booths;
        this.movieTheater = movieTheater;
    }


    /**
     * Starts the ticket office simulation by creating (and starting) threads
     * for each ticket booth to sell tickets for the given movie.
     *
     * @return list of threads used in the simulation,
     *   should have as many threads as there are ticket booths.
     */
    public List<Thread> simulate() {
        // TODO: Implement this method.
        List<Thread> threads = new ArrayList<>();
        for (Map.Entry<String, Seat.SeatType[]> boothEntry : booths.entrySet()) {
            Thread boothThread = new Thread(() -> {
                for (Seat.SeatType types : boothEntry.getValue()) {
                    Seat seat = movieTheater.getNextAvailableSeat(types);
                    int customerId;
                    synchronized (counterLock) {
                        customerId = ++customerIdCounter;
                    }
                    if (seat != null) {
                        synchronized (movieTheater) {
                            movieTheater.printTicket(boothEntry.getKey(), seat, customerId);
                        }
                    }
                }
            });
            threads.add(boothThread);
            boothThread.start();
        }
        return threads;
    }


    public static void main(String[] args) {
        // For your testing purposes. We will not call this method.
    }
}
