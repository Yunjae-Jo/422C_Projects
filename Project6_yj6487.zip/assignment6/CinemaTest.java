package assignment6;

import org.junit.BeforeClass;
import org.junit.Test;
import assignment6.Seat.SeatType;
import java.util.*;

import static org.junit.Assert.*;

public class CinemaTest {
    private static List<Ticket> concurrencyTestLog;
    private static void joinAllThreads(List<Thread> threads)
            throws InterruptedException {
        for (Thread t : threads) {
            t.join();
        }
    }
    @BeforeClass
    public static void setupBeforeClass() throws InterruptedException {
        final SeatType[] seatPreferences = new SeatType[99];
        Arrays.fill(seatPreferences, SeatType.STANDARD);
        final SeatType[] seatPreferences2 = Arrays.copyOf(seatPreferences, 99);

        Map<String, SeatType[]> booths = new HashMap<String, SeatType[]>() {{
            put("TB1", seatPreferences);
            put("TB2", seatPreferences2);
        }};

        MovieTheater movieTheater = new MovieTheater(0, 0, 33);
        Cinema cinema = new Cinema(booths, movieTheater);
        joinAllThreads(cinema.simulate());

        concurrencyTestLog = movieTheater.getTransactionLog();
    }
    // Write your JUnit tests here

    //Tests whether the theater has a maximum number of booking
    @Test
    public void test1() throws InterruptedException {
        final SeatType[] seatPreferences1 = new SeatType[12];
        final SeatType[] seatPreferences2 = new SeatType[12];
        final SeatType[] seatPreferences3 = new SeatType[12];
        Arrays.fill(seatPreferences1, SeatType.RUMBLE);
        Arrays.fill(seatPreferences2, SeatType.COMFORT);
        Arrays.fill(seatPreferences3, SeatType.STANDARD);
        Map<String, SeatType[]> booths = new HashMap<String, SeatType[]>() {{
            put("TB1", seatPreferences1);
            put("TB2", seatPreferences2);
            put("TB3", seatPreferences3);
        }};
        MovieTheater movieTheater = new MovieTheater(2, 2, 2);
        Cinema cinema = new Cinema(booths, movieTheater);
        joinAllThreads(cinema.simulate());
        assertEquals(36, cinema.customerIdCounter);
        assertEquals(36, movieTheater.getSeatLog().size());
    }

    //Tests whether the ticket get properly downgraded twice
    @Test
    public void test2() throws InterruptedException{
        final SeatType[] seatPreferences1 = new SeatType[6];
        final SeatType[] seatPreferences2 = new SeatType[12];
        Arrays.fill(seatPreferences1, SeatType.RUMBLE);
        Arrays.fill(seatPreferences2, SeatType.COMFORT);
        Map<String, SeatType[]> booths = new HashMap<String, SeatType[]>() {{
            put("TB1", seatPreferences1);
            put("TB2", seatPreferences2);
        }};
        MovieTheater movieTheater = new MovieTheater(1, 2, 1);
        Cinema cinema = new Cinema(booths, movieTheater);
        joinAllThreads(cinema.simulate());
        Seat next = movieTheater.getNextAvailableSeat(SeatType.RUMBLE);
        assertNotNull(next);
        assertEquals("4A (STANDARD)", next.toString());
    }

    //Tests when getting the last seat available
    @Test
    public void test3() throws InterruptedException{
        final SeatType[] seatPreferences1 = new SeatType[6];
        final SeatType[] seatPreferences2 = new SeatType[11];
        final SeatType[] seatPreferences3 = new SeatType[6];
        Arrays.fill(seatPreferences1, SeatType.RUMBLE);
        Arrays.fill(seatPreferences2, SeatType.COMFORT);
        Arrays.fill(seatPreferences3, SeatType.STANDARD);
        Map<String, SeatType[]> booths = new HashMap<String, SeatType[]>() {{
            put("TB1", seatPreferences1);
            put("TB2", seatPreferences2);
            put("TB3", seatPreferences3);
        }};
        MovieTheater movieTheater = new MovieTheater(1, 12, 1);
        Cinema cinema = new Cinema(booths, movieTheater);
        joinAllThreads(cinema.simulate());
        Seat next = movieTheater.getNextAvailableSeat(SeatType.COMFORT);
        assertNotNull(next);
        assertEquals("3F (COMFORT)", next.toString());
    }

    //Tests if the function getNextAvailable seat can handle empty seat types
    @Test
    public void test4() throws InterruptedException {
        MovieTheater movieTheater = new MovieTheater(3, 10, 1);
        Seat next = movieTheater.getNextAvailableSeat(SeatType.COMFORT);
        assertNotNull(next);
        assertTrue(next.toString().equalsIgnoreCase("4A (COMFORT)"));
    }

    //Tests when more than 1 booking is done
    @Test
    public void test5() throws InterruptedException {
        final SeatType[] seatPreferences1 = new SeatType[10];
        final SeatType[] seatPreferences2 = new SeatType[3];
        final SeatType[] seatPreferences3 = new SeatType[11];
        Arrays.fill(seatPreferences1, SeatType.RUMBLE);
        Arrays.fill(seatPreferences2, SeatType.COMFORT);
        Arrays.fill(seatPreferences3, SeatType.STANDARD);
        Map<String, SeatType[]> booths = new HashMap<String, SeatType[]>() {{
            put("TB1", seatPreferences1);
            put("TB2", seatPreferences2);
            put("TB3", seatPreferences3);
        }};
        MovieTheater movieTheater = new MovieTheater(2, 1, 2);
        Cinema cinema = new Cinema(booths, movieTheater);
        joinAllThreads(cinema.simulate());
        Seat next1 = movieTheater.getNextAvailableSeat(SeatType.COMFORT);
        Seat next2 = movieTheater.getNextAvailableSeat(SeatType.COMFORT);
        assertNotNull(next1);
        assertNotNull(next2);
        assertEquals("3D (COMFORT)", next1.toString());
        assertEquals("3E (COMFORT)", next2.toString());
    }
}
