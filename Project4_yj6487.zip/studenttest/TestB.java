//package sampletest;
package studenttest;

import unittest.annotations.Test;
import unittest.assertions.Assert;

public class TestB {
    @Test
    public void test3() {
        Assert.assertTrue(false);
    }
}
