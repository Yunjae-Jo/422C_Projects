package sampletest;

import unittest.annotations.Order;
import unittest.annotations.Ordered;
import unittest.annotations.Test;
import unittest.assertions.Assert;
@Ordered
public class TestE {
    @Test
    @Order(3)
    public void testA() {
        Assert.assertEquals(1, 1);
    }
    @Test
    @Order(1)
    public void testC() {
        Assert.assertEquals(3, 1 + 2);
    }
    @Test
    @Order(2)
    public void dtest() {
        Assert.assertEquals(3, 3);
    }
    @Test
    @Order(2)
    public void btest() {Assert.assertEquals(3, 2 + 1);
    }
    @Test
    @Order(2)
    public void etest() {
        Assert.assertTrue(false);
    }
    @Test
    @Order(1)
    public void atest() {Assert.assertEquals(4, 2);}


}