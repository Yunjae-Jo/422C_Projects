package unittest.runners;

import unittest.annotations.Test;
import unittest.assertions.ComparisonException;
import unittest.results.TestClassResult;
import unittest.results.TestMethodResult;
import unittest.assertions.AssertionException;


import java.lang.reflect.Method;
import java.util.*;

public class TestRunner {
    protected Class<?> testClass;

    public TestRunner(Class<?> testClass) {
        this.testClass = testClass;
    }

    public TestClassResult run() {
        TestClassResult finalResults = new TestClassResult(testClass.getName());
        Method[] testMethods = getTestMethods();
        for (Method method : testMethods) {
            TestMethodResult finalResult = runTestMethod(method);
            finalResults.addTestMethodResult(finalResult);
        }
        return finalResults;
    }

    private Method[] getTestMethods() {
        Set<String> methodNames = new HashSet<>();
        List<Method> testMethods = new ArrayList<>();

        Class<?> currentClass = testClass;
        while (currentClass != null) {
            for (Method method : currentClass.getDeclaredMethods()) {
                if (method.isAnnotationPresent(Test.class) && methodNames.add(method.getName())) {
                    testMethods.add(method);
                }
            }
            currentClass = currentClass.getSuperclass();
        }

        testMethods.sort(Comparator.comparing(Method::getName));
        return testMethods.toArray(new Method[0]);
    }

    private TestMethodResult runTestMethod(Method method) {
        try {
            Object run = testClass.getDeclaredConstructor().newInstance();
            method.invoke(run);
            return new TestMethodResult(method.getName(), true, null);
        } catch (Exception e) {
            if (e.getCause() instanceof AssertionException) {
                return new TestMethodResult(method.getName(), false, (AssertionException) e.getCause());
            }
            if (e.getCause() instanceof ComparisonException) {
                return new TestMethodResult(method.getName(), false, (ComparisonException) e.getCause());
            }
            return null;
        }
    }
}
