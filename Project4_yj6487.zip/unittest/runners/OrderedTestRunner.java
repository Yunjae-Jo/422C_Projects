package unittest.runners;

import unittest.annotations.Order;
import unittest.annotations.Test;
import unittest.assertions.ComparisonException;
import unittest.results.TestClassResult;
import unittest.results.TestMethodResult;
import unittest.assertions.AssertionException;


import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;


public class OrderedTestRunner extends TestRunner {

    public OrderedTestRunner(Class<?> testClass) {
        super(testClass);
    }

    @Override
    public TestClassResult run() {
        TestClassResult finalResults = new TestClassResult(testClass.getName());
        Method[] testMethods = getOrderedTestMethods();
        for (Method method : testMethods) {
            TestMethodResult finalResult = runTestMethod(method);
            finalResults.addTestMethodResult(finalResult);
        }
        return finalResults;
    }

    private Method[] getOrderedTestMethods() {
        Set<String> methodNames = new HashSet<>();
        List<Method> testMethods = new ArrayList<>();
        Class<?> currentClass = testClass;
        while (currentClass != null) {
            for (Method method : currentClass.getDeclaredMethods()) {
                if (method.isAnnotationPresent(Test.class) && methodNames.add(method.getName())) {
                    testMethods.add(method);
                }
            }
            currentClass = currentClass.getSuperclass();
        }
        testMethods.sort((i, j) -> {
            Order a = i.getAnnotation(Order.class);
            Order b = j.getAnnotation(Order.class);
            int c = a != null ? a.value() : Integer.MAX_VALUE;
            int d = b != null ? b.value() : Integer.MAX_VALUE;
            if (c != d) {
                return Integer.compare(c, d);
            } else {
                return i.getName().compareTo(j.getName());
            }
        });

        return testMethods.toArray(new Method[0]);
    }


    private TestMethodResult runTestMethod(Method method) {
        try {
            Object run = testClass.getDeclaredConstructor().newInstance();
            method.invoke(run);
            return new TestMethodResult(method.getName(), true, null);
        }
        catch (Exception e) {
            if (e.getCause() instanceof AssertionException) {
                return new TestMethodResult(method.getName(), false, (AssertionException) e.getCause());
            }
            if (e.getCause() instanceof ComparisonException) {
                return new TestMethodResult(method.getName(), false, (ComparisonException) e.getCause());
            }
            return null;
        }
    }
}
