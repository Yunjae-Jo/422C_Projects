package unittest.runners;

import unittest.annotations.Test;
import unittest.results.TestClassResult;
import unittest.results.TestMethodResult;
import unittest.assertions.AssertionException;
import unittest.assertions.ComparisonException;
import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;

public class FilteredTestRunner extends TestRunner {
    private Set<String> testMethodsToRun;
    private Class<?> testClass;
    public FilteredTestRunner(Class testClass, List<String> testMethods) {
        super(testClass);
        // TODO: complete this constructor
        this.testClass = testClass;
        this.testMethodsToRun = new HashSet<>(testMethods);
    }
    // TODO: Finish implementing this class
    @Override
    public TestClassResult run() {
        TestClassResult classResult = new TestClassResult(testClass.getName());
        Method[] allTestMethods = getTestMethods();

        List<Method> sort = Arrays.stream(allTestMethods)
                .filter(m -> testMethodsToRun.contains(m.getName()))
                .collect(Collectors.toList());

        try {
            Object instance = testClass.getDeclaredConstructor().newInstance();
            for (Method method : sort) {
                try {
                    if (method.isAnnotationPresent(Test.class)) {
                        method.invoke(instance);
                        classResult.addTestMethodResult(new TestMethodResult(method.getName(), true, null));
                    }
                } catch (Exception except) {
                    if (except.getCause() instanceof ComparisonException) {
                        classResult.addTestMethodResult(new TestMethodResult(method.getName(), false, (ComparisonException) except.getCause()));
                    } else if (except.getCause() instanceof AssertionException) {
                        classResult.addTestMethodResult(new TestMethodResult(method.getName(), false, (AssertionException) except.getCause()));
                    }
                }
            }
        } catch (Exception except2) {
            except2.printStackTrace();
        }
        return classResult;
    }
    private Method[] getTestMethods() {
        Set<String> methodNames = new HashSet<>();
        List<Method> testMethods = new ArrayList<>();

        Class<?> cClass = testClass;
        while (cClass != null) {
            for (Method method : cClass.getDeclaredMethods()) {
                if (method.isAnnotationPresent(Test.class) && methodNames.add(method.getName())) {
                    testMethods.add(method);
                }
            }
            cClass = cClass.getSuperclass();
        }
        return testMethods.toArray(new Method[0]);
    }
}