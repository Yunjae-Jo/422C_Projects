import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;
public class soundEffect {
    public static void playCheckoutSound() {
        try {
            File audioFile = new File("file_example_WAV_1MG.wav");
            if (!audioFile.exists()) {
                throw new IOException("Audio file not found.");
            }
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(audioFile);
            AudioFormat format = audioInputStream.getFormat();
            DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
            SourceDataLine line = (SourceDataLine) AudioSystem.getLine(info);
            line.open(format);
            line.start();
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = audioInputStream.read(buffer)) != -1) {
                line.write(buffer, 0, bytesRead);
            }
            line.drain();
            line.close();
            audioInputStream.close();
        } catch (IOException | LineUnavailableException | UnsupportedAudioFileException e) {
            System.out.println("Error playing checkout sound: " + e.getMessage());
            e.printStackTrace();
        }
    }
}