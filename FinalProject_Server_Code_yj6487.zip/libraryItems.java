import java.util.Queue;
import java.util.LinkedList;
public class libraryItems {
    private String id;
    private String author;
    private String title;
    private boolean checkedOut;
    private String summary;
    private String type;
    private int pages;
    private Queue<String> reservationQueue = new LinkedList<>();
    private String currentBorrower;
    public libraryItems(String id, String author, String title, boolean checkedOut, String summary, String type, int pages) {
        this.id = id;
        this.author = author;
        this.title = title;
        this.checkedOut = checkedOut;
        this.summary = summary;
        this.type = type;
        this.pages = pages;
    }
    public String getAuthor() {
        return author;
    }
    public String getTitle() {
        return title;
    }
    public boolean isCheckedOut() {
        return checkedOut;
    }
    public String getCurrentBorrower() {
        return currentBorrower;
    }
    public void setCurrentBorrower(String currentBorrower) {
        this.currentBorrower = currentBorrower;
    }
    public String getSummary() {
        return summary;
    }
    public String getType() {
        return type;
    }
    public int getPages() {
        return pages;
    }
    public void setCheckedOut(boolean checkedOut) {
        this.checkedOut = checkedOut;
    }
    public boolean isReserved() {
        return reservationQueue != null && !reservationQueue.isEmpty();
    }
    public boolean reserveItem(String username) {
        if (reservationQueue == null) {
            reservationQueue = new LinkedList<>();
        }
        if (!reservationQueue.contains(username)) {
            reservationQueue.add(username);
            System.out.println("Item reserved for: " + username);
            return true;
        } else {
            System.out.println("User " + username + " has already reserved this item.");
            return false;
        }
    }
    public String getNextReserver() {
        return reservationQueue.poll();
    }
}