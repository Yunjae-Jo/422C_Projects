import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
public class libraryCatalog {
    private ConcurrentHashMap<String, libraryItems> items = new ConcurrentHashMap<>();
    private ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
    public libraryCatalog() {
        loadItems();
    }
    private void loadItems() {
        Gson gson = new Gson();
        try (FileReader reader = new FileReader("items.txt")) {
            List<libraryItems> itemList = gson.fromJson(reader, new TypeToken<List<libraryItems>>() {}.getType());
            itemList.forEach(item -> items.put(item.getTitle(), item));
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Failed to load items from file.");
        }
    }
    public synchronized List<String> searchAvailableItems(String query) {
        if (query == null || query.trim().isEmpty()) {
            System.out.println("Query is empty or null.");
            return new ArrayList<>();
        }
        final String finalQuery = query.trim().toLowerCase();
        System.out.println("Processed query for search: '" + finalQuery + "'");
        return items.values().stream()
                .filter(item -> !item.isCheckedOut() && item.getTitle().toLowerCase().contains(finalQuery))
                .map(item -> item.getTitle() + " by " + item.getAuthor() + (item.isCheckedOut() ? " - Checked out" : " - Available"))
                .collect(Collectors.toList());
    }
    public synchronized List<String> listAllBooks() {
        return items.values().stream()
                .map(item -> item.getTitle() + " by " + item.getAuthor() + (item.isCheckedOut() ? " - Checked out" : " - Available"))
                .collect(Collectors.toList());
    }
    public synchronized boolean checkoutItem(String itemId, String username, userManager userManager) {
        libraryItems item = items.get(itemId);
        if (item == null) {
            System.out.println("Item with ID " + itemId + " does not exist.");
            return false;
        }
        if (item.isCheckedOut()) {
            System.out.println("Item is already checked out.");
            return false;
        }
        item.setCheckedOut(true);
        item.setCurrentBorrower(username);
        userManager.logUserEvent(username, "Checked out: " + item.getTitle());
        scheduler.schedule(() -> {
            synchronized (this) {
                returnItemAutomatically(itemId, username, userManager);
            }
        }, 20, TimeUnit.SECONDS);
        return true;
    }
    private void returnItemAutomatically(String itemId, String username, userManager userManager) {
        libraryItems item = items.get(itemId);
        if (item != null && item.isCheckedOut()) {
            item.setCheckedOut(false);
            userManager.logUserEvent(username, "Automatically returned: " + item.getTitle());
            if (item.isReserved()) {
                String nextUser = item.getNextReserver();
                if (nextUser != null) {
                    checkoutItem(itemId, nextUser, userManager);
                    System.out.println("Item automatically checked out to: " + nextUser);
                }
            }
        }
    }
    public synchronized boolean returnItem(String itemId, String username, userManager userManager) {
        libraryItems item = items.get(itemId);
        if (item != null && item.isCheckedOut()) {
            if (!username.equals(item.getCurrentBorrower())) {
                System.out.println("Attempted return by non-borrower.");
                return false;
            }
            item.setCheckedOut(false);
            item.setCurrentBorrower(null);
            userManager.logUserEvent(username, "Returned: " + item.getTitle());
            if (item.isReserved()) {
                String nextUser = item.getNextReserver();
                if (nextUser != null) {
                    checkoutItem(itemId, nextUser, userManager);
                    System.out.println("Item automatically checked out to: " + nextUser);
                }
            }
            return true;
        }
        return false;
    }
    public void shutdownScheduler() {
        scheduler.shutdown();
        try {
            if (!scheduler.awaitTermination(60, TimeUnit.SECONDS)) {
                scheduler.shutdownNow();
            }
        } catch (InterruptedException e) {
            scheduler.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
    public synchronized boolean reserveItem(String itemId, String username) {
        libraryItems item = items.get(itemId);
        if (item != null) {
            return item.reserveItem(username);
        } else {
            System.out.println("Item with ID " + itemId + " not found.");
            return false;
        }
    }
    public synchronized libraryItems getItem(String itemId) {
        return items.get(itemId);
    }

}