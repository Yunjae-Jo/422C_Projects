import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;
public class clientHandler implements Runnable {
    private Socket socket;
    private libraryCatalog catalog;
    private userManager userManager;
    private ObjectOutputStream output;
    private ObjectInputStream input;
    private String currentUser;
    public clientHandler(Socket socket, libraryCatalog catalog, userManager userManager) {
        this.socket = socket;
        this.catalog = catalog;
        this.userManager = userManager;
        try {
            output = new ObjectOutputStream(socket.getOutputStream());
            input = new ObjectInputStream(socket.getInputStream());
        } catch (IOException e) {
            System.out.println("Error setting up streams: " + e.getMessage());
        }
    }
    @Override
    public void run() {
        try {
            while (true) {
                String request = (String) input.readObject();
                if (request != null) {
                    int idx = request.indexOf(' ');
                    String action = idx > 0 ? request.substring(0, idx) : request;
                    String parameters = idx > 0 ? request.substring(idx + 1) : "";
                    switch (action) {
                        case "login":
                            handleLogin(parameters);
                            break;
                        case "logout":
                            handleLogout();
                            break;
                        case "search":
                            handleSearch(parameters);
                            break;
                        case "checkout":
                            handleCheckout(parameters);
                            break;
                        case "return":
                            handleReturn(parameters);
                            break;
                        case "list_all":
                            handleListAll();
                            break;
                        case "history":
                            handleUserHistory(parameters);
                            break;
                        case "reserve":
                            handleReserve(parameters);
                            break;
                        case "reset_password":
                            handlePasswordReset(parameters);
                            break;
                    }
                    output.flush();
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error handling client: " + e.getMessage());
        } finally {
            closeConnection();
        }
    }
    private void handlePasswordReset(String parameters) throws IOException {
        String[] parts = parameters.split(" ");
        if (parts.length < 3) {
            output.writeObject("Invalid password reset request.");
            return;
        }
        String username = parts[0];
        String oldPassword = parts[1];
        String newPassword = parts[2];
        String response = userManager.resetPassword(username, oldPassword, newPassword);
        output.writeObject(response);
    }
    private void handleReserve(String parameters) throws IOException {
        if (currentUser != null) {
            if (parameters == null || parameters.trim().isEmpty()) {
                output.writeObject("Invalid item ID.");
                return;
            }
            String itemId = parameters.trim();
            boolean reserved = catalog.reserveItem(itemId, currentUser);
            output.writeObject(reserved ? "Reservation successful" : "Item not found or already reserved");
        } else {
            output.writeObject("No user is logged in to perform reservation.");
        }
    }
    private void handleLogin(String credentials) throws IOException {
        String[] parts = credentials.split(" ", 2);
        String username = parts[0];
        String password = (parts.length > 1) ? parts[1] : "";
        String response = userManager.loginUser(username, password);
        if (response.startsWith("Login successful")) {
            currentUser = username;
        }
        output.writeObject(response);
    }
    private void handleLogout() throws IOException {
        if (currentUser != null) {
            String response = userManager.logoutUser(currentUser);
            currentUser = null;
            output.writeObject(response);
        } else {
            output.writeObject("No user is currently logged in.");
        }
    }
    private void handleCheckout(String parameters) throws IOException {
        if (currentUser == null) {
            output.writeObject("No user is logged in to perform checkout.");
            return;
        }
        if (parameters == null || parameters.trim().isEmpty()) {
            output.writeObject("Invalid item ID.");
            return;
        }
        boolean success = catalog.checkoutItem(parameters.trim(), currentUser, userManager);
        output.writeObject(success ? "Checkout successful" : "Checkout failed");
        soundEffect.playCheckoutSound();
    }
    private void handleReturn(String itemId) throws IOException {
        if (currentUser == null) {
            output.writeObject("No user is logged in to perform this action.");
            return;
        }
        if (itemId == null || itemId.trim().isEmpty()) {
            output.writeObject("Invalid item ID provided.");
            return;
        }
        try {
            boolean success = catalog.returnItem(itemId.trim(), currentUser, userManager);
            if (success) {
                output.writeObject("Return successful");
                return;
            } else {
                output.writeObject("Item could not be returned.");
            }
        } catch (NullPointerException e) {
            output.writeObject("Item does not exist or could not be processed.");
            e.printStackTrace();
        }
    }
    private void handleSearch(String query) throws IOException {
        if (query == null || query.trim().isEmpty()) {
            output.writeObject("Please enter a valid search query.");
        } else {
            List<String> results = catalog.searchAvailableItems(query);
            if (results.isEmpty()) {
                output.writeObject("No results found for: " + query);
            } else {
                output.writeObject(results);
            }
        }
    }
    private void handleListAll() throws IOException {
        List<String> allBooks = catalog.listAllBooks();
        output.writeObject(allBooks);
    }
    private void handleUserHistory(String username) throws IOException {
        List<String> history = userManager.getUserHistory(username);
        output.writeObject(history);
    }
    private void closeConnection() {
        try {
            if (currentUser != null) {
                userManager.logoutUser(currentUser);
                currentUser = null;
            }
            if (input != null) {
                input.close();
            }
            if (output != null) {
                output.close();
            }
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            System.out.println("Error closing connection: " + e.getMessage());
        }
    }
}