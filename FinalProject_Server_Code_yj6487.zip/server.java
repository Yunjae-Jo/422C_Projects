import java.net.ServerSocket;
import java.net.Socket;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public class server {
    private static final int PORT = 8000;
    private static libraryCatalog catalog = new libraryCatalog();
    private static userManager userManager = new userManager();

    public static void main(String[] args) {
        ExecutorService pool = Executors.newFixedThreadPool(10);

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server is listening on port " + PORT);

            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                System.out.println("Server is shutting down...");
                catalog.shutdownScheduler();
                pool.shutdown();
            }));
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("New client connected");
                clientHandler clientHandler = new clientHandler(clientSocket, catalog, userManager);
                pool.execute(clientHandler);
            }
        } catch (IOException e) {
            System.out.println("Server exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}