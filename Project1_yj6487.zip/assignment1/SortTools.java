package assignment1;
public class SortTools {
    /**
     * Return whether the first n elements of x are sorted in non-decreasing
     * order.
     *
     * @param x is the array
     * @param n is the size of the input to be checked
     * @return true if first n elements of array is sorted
     */
    public static boolean isSorted(int[] x, int n) {
        // stub only, you write this
        if (n <= 1) {
            return true;
        }
        for (int i = 0; i < n - 1; i++) {
            if (x[i] > x[i + 1]) {
                return false;
            }
        }
        return true;
    }

    /**
     * Return an index of value v within the first n elements of x.
     *
     * @param x is the array
     * @param n is the size of the input to be checked
     * @param v is the value to be searched for
     * @return any index k such that k < n and x[k] == v, or -1 if no such k exists
     */
    public static int find(int[] x, int n, int v) {
        // stub only, you write this!
        int index = -1;
        if (n == 0) {
            return -1;
        }
        for (int i = 0; i < n; i++) {
            if (x[i] == v) {
                index = i;
            }
        }
        // TODO: complete it
        return index;
    }

    /**
     * Return a sorted, newly created array containing the first n elements of x
     * and ensuring that v is in the new array.
     *
     * @param x is the array
     * @param n is the number of elements to be copied from x
     * @param v is the value to be added to the new array if necessary
     * @return a new array containing the first n elements of x as well as v
     */
    public static int[] copyAndInsert(int[] x, int n, int v) {
        // stub only, you write this!
        int size = n;
        int counter = 0;
        if (n == 0) {
            int[] noEle = new int[]{v};
            return noEle;
        }
        for (int i = 0; i < n; i++) {
            if (x[i] == v) {
                counter++;
            }
        }
        if (counter == 0) {
            size = n + 1;
        }

        int[] copied = new int[size];
        boolean trigger = false;
        int counterTrig = 0;
        for (int i = 0; i < size; i++) {
            if (!trigger && (i == size - 1 || x[i] > v) && counterTrig == 0) {
                copied[i] = v;
                trigger = true;
            } else {
                if (trigger) {
                    copied[i] = x[i - 1];
                } else {
                    copied[i] = x[i];
                    if(x[i] == v){
                        counterTrig++;
                    }
                }
            }
        }
        // TODO: complete it
        return copied;
    }

    /**
     * Insert the value v in the first n elements of x if it is not already
     * there, ensuring those elements are still sorted.
     *
     * @param x is the array
     * @param n is the number of elements in the array
     * @param v is the value to be added
     * @return n if v is already in x, otherwise returns n+1
     */
    public static int insertInPlace(int[] x, int n, int v) {
        // stub only, you write this!
        int size = n;
        int counter = 0;
        for (int i = 0; i < n; i++) {
            if (x[i] == v) {
                counter++;
            }
        }
        if (counter == 0) {
            size = n + 1;
        }
        int storage1 = 0;
        int storage2 = 0;
        boolean trigger = false;
        for (int i = 0; i < size; i++) {
            if (trigger) {
                storage2 = x[i];
                x[i] = storage1;
                storage1 = storage2;
            }
            if ((i == size - 1 || x[i] > v) && !trigger && size == n + 1) {
                storage1 = x[i];
                x[i] = v;
                trigger = true;
            }
        }
        // TODO: complete it
        return size;
    }

    /**
     * Sort the first n elements of x in-place in non-decreasing order using
     * insertion sort.
     *
     * @param x is the array to be sorted
     * @param n is the number of elements of the array to be sorted
     */
    public static void insertSort(int[] x, int n) {
        // stub only, you write this!
        int hold = 0;
        int oneLess = 0;
        for (int i = 1; i < n; i++) {
            hold = x[i];
            oneLess = i - 1;
            while (oneLess >= 0 && x[oneLess] > hold) {
                x[oneLess + 1] = x[oneLess];
                oneLess--;
            }
            x[oneLess + 1] = hold;
            // TODO: complete it
        }
    }
}
