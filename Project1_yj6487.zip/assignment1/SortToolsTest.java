package assignment1;
import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.Timeout;

public class SortToolsTest {
    @Rule
    public Timeout globalTimeout = Timeout.seconds(2);

    //isSort tests
    @Test
    public void sampleTestisSorted0() {
        int[] x = new int[]{4};
        int n = x.length;
        assertTrue(SortTools.isSorted(x, n));
    }

    @Test
    public void sampleTestisSorted1() {
        int[] x = new int[]{1, 2, 3, 4, 5};
        int n = x.length;
        assertTrue(SortTools.isSorted(x, n));
    }

    @Test
    public void sampleTestisSorted2() {
        int[] x = new int[]{5, 4, 3, 2, 1};
        int n = x.length;
        assertFalse(SortTools.isSorted(x, n));
    }

    @Test
    public void sampleTestisSorted3() {
        int[] x = new int[]{7, 5};
        int n = x.length;
        assertFalse(SortTools.isSorted(x, n));
    }

    @Test
    public void sampleTestisSorted4() {
        int[] x = new int[]{-5, -2, 15, 20};
        int n = x.length;
        assertTrue(SortTools.isSorted(x, n));
    }

    @Test
    public void sampleTestisSorted5() {
        int[] x = new int[]{-5, 0, 10, 15, 12};
        int n = x.length;
        assertFalse(SortTools.isSorted(x, n));
    }

    @Test
    public void sampleTestisSorted6() {
        int[] x = new int[]{4, 7, 12, 10, 15, 19};
        int n = x.length;
        assertFalse(SortTools.isSorted(x, n));
    }


    //find tests
    @Test
    public void sampleTestfind0() {
        int[] x = new int[]{1, 2, 3, 4, 5};
        int n = x.length;
        int v = 3;
        assertEquals(2, SortTools.find(x, n, v));
    }

    @Test
    public void sampleTestfind1() {
        int[] x = new int[]{1};
        int n = x.length;
        int v = 1;
        assertEquals(0, SortTools.find(x, n, v));
    }

    @Test
    public void sampleTestfind2() {
        int[] x = new int[]{1, 2, 3, 4, 5};
        int n = x.length;
        int v = 6;
        assertEquals(-1, SortTools.find(x, n, v));
    }

    @Test
    public void sampleTestfind3() {
        int[] x = new int[]{};
        int n = x.length;
        int v = 2;
        assertEquals(-1, SortTools.find(x, n, v));
    }

    @Test
    public void sampleTestfind4() {
        int[] x = new int[]{1, 2, 4, 6, 7};
        int n = x.length;
        int v = 2;
        assertEquals(1, SortTools.find(x, n, v));
    }


    //copyAndInsert tests
    @Test
    public void sampleTestcopyAndInsert0() {
        int[] x = new int[]{1, 2, 4, 6, 7};
        int n = x.length;
        int v = 5;
        int[] correct = new int[]{1, 2, 4, 5, 6, 7};
        assertArrayEquals(correct, SortTools.copyAndInsert(x, n, v));
    }

    @Test
    public void sampleTestcopyAndInsert1() {
        int[] x = new int[]{};
        int n = x.length;
        int v = 5;
        int[] correct = new int[]{5};
        assertArrayEquals(correct, SortTools.copyAndInsert(x, n, v));
    }

    @Test
    public void sampleTestcopyAndInsert2() {
        int[] x = new int[]{1};
        int n = x.length;
        int v = 5;
        int[] correct = new int[]{1, 5};
        assertArrayEquals(correct, SortTools.copyAndInsert(x, n, v));
    }

    @Test
    public void sampleTestcopyAndInsert3() {
        int[] x = new int[]{1, 2, 3, 4};
        int n = x.length;
        int v = 0;
        int[] correct = new int[]{0, 1, 2, 3, 4};
        assertArrayEquals(correct, SortTools.copyAndInsert(x, n, v));
    }

    @Test
    public void sampleTestCopyAndInsert4() {
        int[] x = new int[]{5, 8, 10, 12, 15};
        int n = x.length;
        int v = 9;
        int[] correct = new int[]{5, 8, 9, 10, 12, 15};
        assertArrayEquals(correct, SortTools.copyAndInsert(x, n, v));
    }

    @Test
    public void sampleTestCopyAndInsert5() {
        int[] x = new int[]{1, 3, 5, 7, 9};
        int n = x.length;
        int v = 6;
        int[] correct = new int[]{1, 3, 5, 6, 7, 9};
        assertArrayEquals(correct, SortTools.copyAndInsert(x, n, v));
    }

    @Test
    public void sampleTestCopyAndInsert6() {
        int[] x = new int[]{2, 4, 6, 8, 10};
        int n = x.length;
        int v = 1;
        int[] correct = new int[]{1, 2, 4, 6, 8, 10};
        assertArrayEquals(correct, SortTools.copyAndInsert(x, n, v));
    }

    @Test
    public void sampleTestCopyAndInsert7() {
        int[] x = new int[]{10, 20, 30, 40, 50};
        int n = x.length;
        int v = 25;
        int[] correct = new int[]{10, 20, 25, 30, 40, 50};
        assertArrayEquals(correct, SortTools.copyAndInsert(x, n, v));
    }


    //insertInPlace tests
    @Test
    public void sampleTestinsertInplace0() {
        int[] x = new int[]{1, 2, 4, 6, 7};
        int[] correct = new int[]{1, 2, 4, 5, 7};
        int n = 3;
        int v = 5;
        int result = SortTools.insertInPlace(x, n, v);
        assertEquals(4, result);

    }

    @Test
    public void sampleTestinsertInplace1() {
        int[] x = new int[]{2, 3};
        int[] correct = new int[]{2, 5};
        int n = 1;
        int v = 5;
        int result = SortTools.insertInPlace(x, n, v);
        assertEquals(2, result);

    }

    @Test
    public void sampleTestinsertInplace2() {
        int[] x = new int[]{1, 4, 5, 7};
        int[] correct = new int[]{1, 4, 5, 9};
        int n = 3;
        int v = 9;
        int result = SortTools.insertInPlace(x, n, v);
        assertEquals(4, result);

    }

    @Test
    public void sampleTestinsertInplace3() {
        int[] x = new int[]{1, 2, 3, 4};
        int[] correct = new int[]{0, 1, 2, 4};
        int n = 2;
        int v = 0;
        int result = SortTools.insertInPlace(x, n, v);
        assertEquals(3, result);

    }

    @Test
    public void sampleTestinsertInplace4() {
        int[] x = new int[]{5, 8, 10, 12, 15};
        int[] correct = new int[]{5, 8, 10, 12, 15};
        int n = 4;
        int v = 8;
        int result = SortTools.insertInPlace(x, n, v);
        assertEquals(4, result);

    }

    @Test
    public void sampleTestinsertInplace5() {
        int[] x = new int[]{1, 3, 5, 7, 9};
        int[] correct = new int[]{1, 2, 3, 5, 7};
        int n = 4;
        int v = 2;
        int result = SortTools.insertInPlace(x, n, v);
        assertEquals(5, result);

    }


    //inserSort test
    @Test
    public void sampleTestinsertSort0() {
        int[] x = new int[]{10, 1, 5, 6, 9};
        int[] correct = new int[]{1, 10, 5, 6, 9};
        int n = 2;
        SortTools.insertSort(x, n);
        assertArrayEquals(correct, x);
    }

    @Test
    public void sampleTestinsertSort1() {
        int[] x = {7, 3, 1, 3};
        int[] correct = {1, 3, 3, 7};
        int n = 4;
        SortTools.insertSort(x, n);
        assertArrayEquals(correct, x);
    }

    @Test
    public void sampleTestinsertSort2() {
        int[] x = {1, 2, 3, 4, 5};
        int[] correct = {1, 2, 3, 4, 5};
        int n = 5;
        SortTools.insertSort(x, n);
        assertArrayEquals(correct, x);
    }

    @Test
    public void sampleTestinsertSort3() {
        int[] x = {42};
        int[] correct = {42};
        int n = 1;
        SortTools.insertSort(x, n);
        assertArrayEquals(correct, x);
    }

    @Test
    public void sampleTestinsertSort4() {
        int[] x = {2, 1, 3, 4, 5};
        int[] correct = {1, 2, 3, 4, 5};
        int n = 5;
        SortTools.insertSort(x, n);
        assertArrayEquals(correct, x);
    }

    @Test
    public void sampleTestinsertSort5() {
        int[] x = {5, 4, 3, 2, 1};
        int[] correct = {1, 2, 3, 4, 5};
        int n = 5;
        SortTools.insertSort(x, n);
        assertArrayEquals(correct, x);
    }

    @Test
    public void sampleTestinsertSort6() {
        int[] x = {2, 1, 3, 4, 5};
        int[] correct = {1, 2, 3, 4, 5};
        int n = 5;
        SortTools.insertSort(x, n);
        assertArrayEquals(correct, x);
    }
}

